package ASS5;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.NumberFormat;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class HolidayBonusGui extends Application {
    private double[][] sales;
    public static final int MAX_STORES = 6;
    public static final int MAX_ITEMS = 6;
    private NumberFormat currencyFormat = NumberFormat.getCurrencyInstance();
    Button readFileBtn, exitBtn, copyFileBtn;
    GridPane dataPane;

    public void readFile() throws IOException {
        File selectedFile;
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Choose a file to read retail items' sales information");
        if ((selectedFile = chooser.showOpenDialog(null)) != null) {
            sales = TwoDimRaggedArrayUtility.readFile(selectedFile);
        }

        clearTable();
        int row, col;
        double total, lowest, highest;
        for (row = 0; row < sales.length; row++)
            for (col = 0; col < sales[row].length; col++)
                dataPane.add(new TextField(currencyFormat.format(sales[row][col])), col + 1, row + 1);

        for (row = 0; row < sales.length; row++) {
            total = TwoDimRaggedArrayUtility.getRowTotal(sales, row);
            dataPane.add(new TextField(currencyFormat.format(total)), 7, row + 1);
        }

        int columns = 0;
        for (row = 0; row < sales.length; row++)
            if (sales[row].length > columns)
                columns = sales[row].length;

        for (col = 0; col < columns; col++) {
            total = TwoDimRaggedArrayUtility.getColumnTotal(sales, col);
            dataPane.add(new TextField(currencyFormat.format(total)), col + 1, 7);
        }

        total = TwoDimRaggedArrayUtility.getTotal(sales);
        dataPane.add(new TextField(currencyFormat.format(total)), 7, 7);

        double[] result = HolidayBonus.calculateHolidayBonus(sales);
        for (row = 0; row < sales.length; row++) {
            dataPane.add(new TextField(currencyFormat.format(result[row])), 8, row + 1);
        }

        double bonus = HolidayBonus.calculateTotalHolidayBonus(sales);
        dataPane.add(new TextField(currencyFormat.format(bonus)), 8, 7);

        for (col = 0; col < columns; col++) {
            highest = TwoDimRaggedArrayUtility.getHighestInColumn(sales, col);
            TextField temp = new TextField(currencyFormat.format(highest));
            temp.setStyle("-fx-background-color: green;");
            for (row = 0; row < sales.length; row++) {
                if (col < sales[row].length) {
                    if (sales[row][col] == highest) {
                        dataPane.add(temp, col + 1, row + 1);
                    }
                }
            }
        }

        for (col = 0; col < columns; col++) {
            lowest = TwoDimRaggedArrayUtility.getLowestInColumn(sales, col);
            highest = TwoDimRaggedArrayUtility.getHighestInColumn(sales, col);
            if (lowest == highest) continue;
            TextField temp = new TextField(currencyFormat.format(lowest));
            temp.setStyle("-fx-background-color: red;");
            for (row = 0; row < sales.length; row++) {
                if (col < sales[row].length) {
                    if (sales[row][col] == lowest) {
                        dataPane.add(temp, col + 1, row + 1);
                    }
                }
            }
        }