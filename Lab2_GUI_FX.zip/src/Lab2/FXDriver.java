package Lab2;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class FXDriver extends Application {
    @Override
    public void start(Stage stage) {
        // Create an instance of FXMainPane (ensure this class exists)
        FXMainPane root = new FXMainPane();
        
        // Set the scene with width 600px and height 400px
        stage.setScene(new Scene(root, 600, 400));
        
        // Set the title of the window (optional)
        stage.setTitle("JavaFX Application");

        // Show the stage
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);  // Use the inherited launch method from Application
    }
}