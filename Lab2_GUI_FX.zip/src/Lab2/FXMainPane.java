package Lab2;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.control.TextField;
import javafx.geometry.Insets;

public class FXMainPane extends VBox {
    // Declare the components
    Button button1, button2, button3, button4, button5;
    Label feedbackLabel;
    TextField textField;
    HBox hBox1, hBox2;
    DataManager dataManager;

    public FXMainPane() {
        // Instantiate the DataManager
        dataManager = new DataManager();

        // Instantiate the buttons
        button1 = new Button("Hello");
        button2 = new Button("Howdy");
        button3 = new Button("Chinese");
        button4 = new Button("Clear");
        button5 = new Button("Exit");

        // Instantiate the label and text field
        feedbackLabel = new Label("Feedback:");
        textField = new TextField();

        // Instantiate the HBoxes
        hBox1 = new HBox();
        hBox2 = new HBox();

        // Set button actions using the ButtonHandler
        ButtonHandler handler = new ButtonHandler();
        button1.setOnAction(handler);
        button2.setOnAction(handler);
        button3.setOnAction(handler);
        button4.setOnAction(handler);
        button5.setOnAction(handler);

        // Add buttons to hBox1
        hBox1.getChildren().addAll(button1, button2, button3, button4, button5);
        hBox1.setAlignment(Pos.CENTER);
        HBox.setMargin(button1, new Insets(10));
        HBox.setMargin(button2, new Insets(10));
        HBox.setMargin(button3, new Insets(10));
        HBox.setMargin(button4, new Insets(10));
        HBox.setMargin(button5, new Insets(10));

        // Add label and text field to hBox2
        hBox2.getChildren().addAll(feedbackLabel, textField);
        hBox2.setAlignment(Pos.CENTER);
        HBox.setMargin(feedbackLabel, new Insets(10));
        HBox.setMargin(textField, new Insets(10));

        // Add the HBoxes to the VBox
        this.getChildren().addAll(hBox1, hBox2);
        this.setAlignment(Pos.CENTER);
        VBox.setMargin(hBox1, new Insets(10));
        VBox.setMargin(hBox2, new Insets(10));
    }

    // Inner class to handle button actions
    private class ButtonHandler implements EventHandler<ActionEvent> {
        @Override
        public void handle(ActionEvent event) {
            Button source = (Button) event.getSource();

            if (source == button1) {
                textField.setText(dataManager.getHello());
            } else if (source == button2) {
                textField.setText(dataManager.getHowdy());
            } else if (source == button3) {
                textField.setText(dataManager.getChinese());
            } else if (source == button4) {
                textField.clear();
            } else if (source == button5) {
                Platform.exit();
                System.exit(0);
            }
        }
    }
}