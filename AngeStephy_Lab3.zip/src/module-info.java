/**
 * 
 */
/**
 * 
 */
module AS3 {
	requires junit;
	requires org.junit.jupiter.api;
}